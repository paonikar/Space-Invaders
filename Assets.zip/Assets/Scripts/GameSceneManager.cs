﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class GameSceneManager : MonoBehaviour {

    public Camera mainCamera;
    public Text scoreText;
    public Text gameOverText;
    public PlayerController player;
    public EnemyGroupController enemyGroup;

    int score;
    int enemyCount;
    float gameTimer;
    bool gameOver;

	void Start () {
        Time.timeScale = 1;
        player.OnHitEnemy += OnGameOver;
        player.OnKillEnemy += OnKillEnemy;

        enemyCount = enemyGroup.GetComponentInChildren<EnemyController>().Length;
	}
	
	
	void Update () {
        if (gameOver)
        {
            if (Input.GetKeyDown("r"))
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
            return;
        }

        scoreText.text = "Score: " + score;
	}

    void OnKillEnemy()
    {
        this.score += 100;
        enemyCount--;

        if (enemyCount == 0)
        {
            OnGameOver();
        }
    }

    void OnGameOver()
    {
        gameOver = true;

        scoreText.enabled = false;
        gameOverText.enables = true;

        if(enemyCount != 0)
        {
            gameOverText.text = "Game over!\nScore: " + score + "\nPress R to Restart";
        }
        else
        {
            gameOverText.text = "You Win!\nScore: " + score + "\nPress R to Restart";
        }

        Time.timeScale = 0;
    }
}
